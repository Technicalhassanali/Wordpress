<?php

namespace fivefilters\Readability\Nodes\DOM;

use fivefilters\Readability\Nodes\NodeTrait;

class DOMCdataSection extends \DOMCdataSection
{
    use NodeTrait;
}
