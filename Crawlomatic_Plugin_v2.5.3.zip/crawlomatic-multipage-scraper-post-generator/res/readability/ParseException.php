<?php

namespace fivefilters\Readability;

class ParseException extends \Exception
{
}
