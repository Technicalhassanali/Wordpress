<?php

namespace vipnytt\SitemapParser\Exceptions;

/**
 * TransferException class
 *
 * @license https://opensource.org/licenses/MIT MIT license
 * @link https://github.com/VIPnytt/SitemapParser
 */
class TransferException extends SitemapParserException
{
}
